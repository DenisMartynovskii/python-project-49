#!/usr/bin/env python3.7
from brain_games.cli import run


def main():
	print('Welcome to the Brain Games!')
	run()	


if __name__ == '__main__':
	main()
	

#!/usr/bin/env python3
#import sys
#from cli import welcome_user


def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()


#sys.path.insert(0, '/home/adduser/project/brain_games')

#welcome_user('qwe')

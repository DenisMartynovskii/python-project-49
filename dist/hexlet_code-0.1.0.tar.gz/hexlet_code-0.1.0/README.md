### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenisMartynovskii/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenisMartynovskii/python-project-49/actions)
https://asciinema.org/a/v9gq5IA5hkP6mjYvj4KDBKgJP
https://asciinema.org/connect/04cc64b4-b0e2-44df-aa6e-e20794805eb6
https://asciinema.org/connect/04cc64b4-b0e2-44df-aa6e-e20794805eb6

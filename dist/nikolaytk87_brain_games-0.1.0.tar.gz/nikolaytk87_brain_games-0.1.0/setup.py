# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['brain_games']

package_data = \
{'': ['*'], 'brain_games': ['scripts/*']}

entry_points = \
{'console_scripts': ['brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'nikolaytk87-brain-games',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Nick',
    'author_email': 'nick@tt.local',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
